# 项目启动文档 — 移植开发

> 使用方式：填写完成后给 Claude Code，告诉它读取以下路径的 Skill 文件，然后按 Skill 流程开始。

---

## Skill 路径

> Skill Index 路径根据 Skills 根目录自动推算为 `[Skills 根目录]\port\00-INDEX.md`，无需单独填写。

- **引擎规范文件路径**：XXX（例：E:\skills\UNITY-RULES.md）
- **视觉规范文件路径**：XXX（例：E:\skills\UNITY-VISUAL-RULES.md，没有就写"无"）

---

## 引擎路径

- **引擎可执行文件路径**：XXX（例：C:\Godot\Godot_v4.6.exe 或 /Applications/Unity/Unity.app/Contents/MacOS/Unity）

---

## 项目文件路径

- **原始代码路径**：XXX（原版项目的完整路径，例：E:\Projects\OriginalGame）
- **目标工程路径**：XXX（移植后的新项目路径，例：E:\Projects\NewGame）
- **美术资源路径**：XXX（图片、音效、字体等资源的位置）
- **其他资源路径**：XXX（配置文件、数据文件等，没有就写"无"）
- **交接摘要路径**：XXX（例：E:\Projects\NewGame\handover.md，每次开新窗口读取这个文件继续）

> 启动后第一件事：把 CLAUDE.md 复制到目标工程路径的根目录下。CLAUDE.md 模板路径：XXX（例：E:\skills\CLAUDE.md）

---

## 基本信息

- **项目名称**：XXX
- **原始平台/框架**：XXX（例如：Web JS / Unity 2019 / Flash）
- **目标引擎/框架**：XXX（Unity / Godot / Unreal / Web）
- **目标平台**：XXX（PC / Mobile / Web / Console）
- **开发语言**：XXX

---

## 移植方式

- **移植类型**：XXX（纯1:1移植 / 移植+视觉升级 / 移植+部分重设计）
- **视觉目标**：XXX（保持原版视觉 / 升级到目标引擎原生效果）

---

## 已知 Bug

XXX
（原版有哪些已知问题，移植时是保留还是修复，没有就写"无"）

---

## 故意要改的地方

XXX
（有哪些地方不是1:1移植，而是要刻意修改或改进，没有就写"无"）

---

## 技术限制

XXX
（目标设备最低配置、性能要求、特殊限制，没有就写"无"）

---

## 不需要移植的功能

XXX
（原版有但这次不需要移植的功能，没有就写"无"）

---

## 其他备注

XXX

---

## Skills 工具路径

> 填写一次，以后所有项目共用

- **Skills 根目录**：XXX（例：E:\skills，所有 Skill 文件、Rules、CLAUDE.md 都在这里）

---

## 启动后立即执行

根据上方填写的 **Skills 根目录**，自动执行以下操作：

1. **写入 Rules：**
   读取 `[Skills 根目录]\RULES.md`，通过 `/rules` 写入 CLI 配置。
   验证写入成功后告知用户：✅ Rules 已写入 / ❌ 写入失败

2. **复制 CLAUDE.md：**
   将 `[Skills 根目录]\CLAUDE.md` 复制到目标工程路径的根目录。
   告知用户：✅ CLAUDE.md 已复制 / ❌ 复制失败

3. **建立 Plugin 结构：**
   检查以下路径是否存在，不存在则自动创建并从 Skills 根目录复制对应文件：
   ```
   [Skills 根目录]\port\
     .claude-plugin\plugin.json
     skills\port-dev\SKILL.md
   ```
   告知用户：✅ Plugin 结构已就绪 / ❌ 创建失败

所有步骤完成后汇报结果，然后继续读取 Skill Index 开始流程。
