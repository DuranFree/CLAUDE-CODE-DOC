# 项目启动文档 — 从零开发

> 使用方式：填写完成后给 Claude Code，告诉它读取以下路径的 Skill 文件，然后按 Skill 流程开始。

---

## Skill 路径

> Skill Index 路径根据 Skills 根目录自动推算为 `[Skills 根目录]\scratch\00-INDEX.md`，无需单独填写。

- **引擎规范文件路径**：XXX（例：E:\skills\GODOT-RULES.md）
- **视觉规范文件路径**：XXX（例：E:\skills\GODOT-VISUAL-RULES.md，没有就写"无"）

---

## 引擎路径

- **引擎可执行文件路径**：XXX（例：C:\Godot\Godot_v4.6.exe 或 /Applications/Godot.app/Contents/MacOS/Godot）

---

## 项目文件路径

- **项目工程路径**：XXX（新项目将在这里创建，例：E:\Projects\MyGame）
- **美术资源路径**：XXX（图片、音效、字体等资源的位置，没有就写"待定"）
- **交接摘要路径**：XXX（例：E:\Projects\MyGame\handover.md，每次开新窗口读取这个文件继续）

> 启动后第一件事：把 CLAUDE.md 复制到项目工程路径的根目录下。CLAUDE.md 模板路径：XXX（例：E:\skills\CLAUDE.md）

---

## 基本信息

- **项目名称**：XXX
- **目标引擎/框架**：XXX（Unity / Godot / Unreal / Web）
- **目标平台**：XXX（PC / Mobile / Web / Console）
- **开发语言**：XXX

---

## 游戏类型与核心玩法

XXX
（例如：回合制卡牌游戏，玩家和AI各自出牌，根据战力值结算胜负）

---

## 核心规则

XXX
（把最基本的游戏规则写清楚，不需要很详细，但要让AI理解游戏怎么玩）

---

## 参考游戏

XXX
（我想做类似 XX 的游戏，视觉/玩法参考）

---

## 技术限制

XXX
（目标设备最低配置、性能要求、特殊限制，没有就写"无"）

---

## 不需要做的功能

XXX
（明确排除的功能，避免 AI 自作主张加进去，没有就写"无"）

---

## 其他备注

XXX

---

## Skills 工具路径

> 填写一次，以后所有项目共用

- **Skills 根目录**：XXX（例：E:\skills，所有 Skill 文件、Rules、CLAUDE.md 都在这里）

---

## 启动后立即执行

根据上方填写的 **Skills 根目录**，自动执行以下操作：

1. **写入 Rules：**
   读取 `[Skills 根目录]\RULES.md`，通过 `/rules` 写入 CLI 配置。
   验证写入成功后告知用户：✅ Rules 已写入 / ❌ 写入失败

2. **复制 CLAUDE.md：**
   将 `[Skills 根目录]\CLAUDE.md` 复制到项目工程路径的根目录。
   告知用户：✅ CLAUDE.md 已复制 / ❌ 复制失败

3. **建立 Plugin 结构：**
   检查以下路径是否存在，不存在则自动创建并从 Skills 根目录复制对应文件：
   ```
   [Skills 根目录]\scratch\
     .claude-plugin\plugin.json
     skills\scratch-dev\SKILL.md
   ```
   告知用户：✅ Plugin 结构已就绪 / ❌ 创建失败

所有步骤完成后汇报结果，然后继续读取 Skill Index 开始流程。
