---
name: scratch-dev
description: Full workflow for building a new game from scratch. Use when user wants to create a new game, build from zero, start a new project, or mentions "从零开发" or "新游戏".
---

# Scratch Dev — 从零开发游戏工作流

读取 `../../00-INDEX.md` 开始流程。
