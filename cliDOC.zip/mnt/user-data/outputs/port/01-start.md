# Port / Migration — 全局规则

这些规则适用于整个工作流的每一个阶段，始终有效，不可忽略。

---

## GitHub 确认

Ask the user:
> "是否需要关联 GitHub 仓库？Architecture Improvement 阶段会用到 GitHub Issues 来记录重构任务。如果没有，该阶段会跳过 Issue 创建步骤。"

If yes, confirm `gh` CLI is installed and logged in before proceeding. If no, skip all `gh issue create` steps silently.

---

## 版本控制规则

After every Phase where all tests pass, check if a git repository is connected:
- **If yes** → automatically commit: `git commit -m "Phase X: ported <system> - all tests passing"`
- **If no** → notify the user every time: `⚠️ [版本控制] 未检测到 git 仓库，跳过本次 commit。如需版本控制保护，请关联 git 仓库。`

Never skip the check itself.

---

## 开发日志规则

After every Phase, automatically append to `./logs/dev-log.md` in the current project folder. Create if it doesn't exist:

```
## Phase <number>: <title> — <date>
**Status**: ✅ Completed / ⚠️ Partially completed
**What was done**: <brief summary>
**Decisions made**: <any architectural or design decisions>
**Technical debt**: <anything skipped or deferred, with reason>
**Problems encountered**: <any issues found and how they were resolved>
```

---

## 持久化文件规则

以下文件必须在项目文件夹里维护，贯穿整个开发周期。每个文件的更新方式不同，严格遵守：

### 文件结构
```
<project>/
  plans/
    feature-checklist.md   ← 功能清单，完成打勾，持续更新
    visual-checklist.md    ← 视觉清单，完成打勾，持续更新
    tech-debt.md           ← 技术债，解决后删除，新增时追加
    known-bugs.md          ← 已知 Bug，修复后标记 ✅，新增时追加
    deep-scan-results.md   ← Phase 1 生成，之后不再修改
  logs/
    dev-log.md             ← 每个 Phase 追加，不覆盖
  handover.md              ← 每次生成交接摘要时覆盖
```

### 各文件更新规则

**feature-checklist.md**
- Phase 1 生成完整功能清单后创建
- 每完成一个功能项立即更新，标记 ✅
- 不删除任何项目，只更新状态

**visual-checklist.md**
- Phase 2 生成视觉清单后创建
- 每完成一个视觉项立即更新，标记 ✅
- 不删除任何项目，只更新状态

**tech-debt.md**
- 发现技术债时追加
- 解决后删除对应条目
- 格式：`- [ ] <描述> — 原因：<why deferred> — Phase <number>`

**known-bugs.md**
- 发现 bug 时追加
- 修复后标记 ✅，不删除
- 格式：`- [ ] <描述> — 发现于 Phase <number>`

**deep-scan-results.md**
- Phase 1 深度扫描完成后创建
- 包含：硬编码数值、配置文件、交互流程链
- **之后不再修改**

---

## 交接摘要规则

After every 2-3 complex Phases, or whenever the context has been compressed, proactively tell the user:

> "建议现在开新窗口，我来生成交接摘要。"

Then automatically overwrite `handover.md` with:

```
## 交接摘要 — <date>

**新窗口启动指令：**
读取本文件，然后读取以下所有文件，按指引继续开发。

## 需要读取的文件
- Skill Index：<path from KICKOFF>
- 引擎规范：<path from KICKOFF>
- 视觉规范：<path from KICKOFF>
- 开发日志：<project path>/logs/dev-log.md
- 功能清单：<project path>/plans/feature-checklist.md
- 视觉清单：<project path>/plans/visual-checklist.md
- 技术债：<project path>/plans/tech-debt.md
- 已知 Bug：<project path>/plans/known-bugs.md

## 当前状态
- **已完成**：Phase <list>
- **下一步**：Phase <number>，从 <specific starting point> 开始
- **未解决的问题**：<list or "无">
- **技术债数量**：<number> 条
- **未修复 Bug 数量**：<number> 条

## 重要路径
- 项目路径：<path from KICKOFF>
- 引擎可执行文件路径：<path from KICKOFF>
- 交接摘要路径：<path from KICKOFF>
```

**生成交接摘要后停止，等待用户开新窗口继续。**

**交接摘要生成完毕后，立即停止所有工作，等待用户开新窗口。不要自己继续下一个 Phase。**

---

读取完毕后，立即读取 `02-requirements.md` 开始 Phase 1。
