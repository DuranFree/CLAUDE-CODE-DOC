# From-Scratch Development — Skill Index

## CLI 安装方式（推荐）
```
/plugin marketplace add [你的 scratch 文件夹路径]
/plugin install scratch-dev
```
安装后直接说"开始新游戏项目"或"从零开发"，Claude 会自动加载。

## Desktop / 手动使用方式
开始项目时告诉 Claude Code：
> "请读取 scratch/00-INDEX.md 和 PROJECT-KICKOFF-scratch.md 然后开始"

---

## 执行顺序

每完成一个阶段才读取下一个文件，不要一次性读取所有文件。

| 阶段 | 文件 | 内容 |
|---|---|---|
| 开始前 | `01-start.md` | 全局规则（版本控制、开发日志）— 立即读取 |
| Phase 1 | `02-requirements.md` | Grill Me + 功能清单 |
| Phase 2 | `03-prd-plan.md` | PRD + 计划拆分 |
| Phase 3 | `04-tdd.md` | TDD 实现 |
| Phase 4 | `05-architecture.md` | 架构优化（项目完成后） |

---

## 立即执行

1. 读取 `01-start.md`
2. 读取 `02-requirements.md` 开始 Phase 1
